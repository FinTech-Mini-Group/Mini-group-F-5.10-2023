import React from 'react'
import noutbuk from '../assets/Mask group.png'

function Instructiontwo() {
  return (
    <div className='lg:w-[100%] lg:flex justify-between my-[50px] bg-Cbanner bg-no-repeat gap-1'>
          <h2 className='lg:text-Instruct text-white py-[71px] lg:pl-[50px] '>Ноутбуки для программистов</h2>
          <img src={noutbuk} alt="" />
    </div>
  )
}

export default Instructiontwo