import React from 'react'

export default function Сharacter(props) {
    
  return (
    <div className={props.title === 'Character' ? 'block' : 'hidden'}>
      <h2>ghghg</h2>
    </div>
  )
}

