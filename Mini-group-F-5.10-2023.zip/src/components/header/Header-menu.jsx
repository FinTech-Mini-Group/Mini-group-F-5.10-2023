import { Link } from "react-router-dom";

export const catalog=[
    {
        linkname:<Link to={'/catalog'}>Каталог</Link>,
        slug:"/Catalog",

    },
]